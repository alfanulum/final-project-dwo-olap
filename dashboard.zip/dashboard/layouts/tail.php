<!-- latest jquery-->
<script src="./assets/js/jquery.min.js"></script>
<!-- Bootstrap js-->
<script src="./assets/js/bootstrap/bootstrap.bundle.min.js"></script>
<!-- feather icon js-->
<script src="./assets/js/icons/feather-icon/feather.min.js"></script>
<script src="./assets/js/icons/feather-icon/feather-icon.js"></script>
<!-- scrollbar js-->
<script src="./assets/js/scrollbar/simplebar.js"></script>
<script src="./assets/js/scrollbar/custom.js"></script>
<!-- Sidebar jquery-->
<script src="./assets/js/config.js"></script>
<!-- Plugins JS start-->
<script src="./assets/js/sidebar-menu.js"></script>
<script src="./assets/js/sidebar-pin.js"></script>
<script src="./assets/js/slick/slick.min.js"></script>
<script src="./assets/js/slick/slick.js"></script>
<script src="./assets/js/header-slick.js"></script>
<!-- Theme js-->
<script src="./assets/js/script.js"></script>
</body>

</html>